#ifndef RYAN_INCLUDE
#define RYAN_INCLUDE

extern int mpi_p, mpi_id;

extern char *id2string();

#endif
